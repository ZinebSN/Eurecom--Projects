import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie.model';
import { MoviesService } from '../movies.service';
import { User } from '../user.model';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  user: User;
  movie:Movie;
  movies:Movie[]=[];
  wishlist:Movie[]=[];
  notEmpty:boolean=true;
  constructor(public moviesService:MoviesService) { }

  ngOnInit(): void {
    this.user=this.moviesService.getUser();
 
    
    this.moviesService.getWishlist().subscribe(movies => {this.wishlist=movies});
    //this.notEmpty=(this.wishlist.length>0);
    console.log(this.wishlist);
    //this.moviesService.getWishlist().subscribe((movies: Movie[])=>{
      //this.movies=movies
    //});
  }

  removeFromWishlist(movie){
    this.moviesService.removeMovie(movie);
  }

}
