import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import firebase from 'firebase/compat/app';
import { User } from './user.model';
import { Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Movie } from './movie.model';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';
import { AngularFireDatabaseModule } from '@angular/fire/compat/database';


@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  private user: User ;
  private movies: Movie[]=[];
  private wish:number[]=[];
  
  constructor(private afAuth: AngularFireAuth, private router: Router, private firestore:AngularFirestore, private realtimedb:AngularFireDatabase) { }

  async signInWithGoogle() {
    const credientals= await this.afAuth.signInWithPopup(new firebase.auth.GoogleAuthProvider)
    
    this.user= {
      
      uid: credientals.user.uid,
      
      displayName:credientals.user.displayName,
      
      email:credientals.user.email
    };

    localStorage.setItem("user", JSON.stringify(this.user));
    this.updateUserData();
    this.router.navigate(["dashboard"]);
  }

  private updateUserData() {
    this.firestore.collection("users").doc(this.user.uid).set({
      uid:this.user.uid,
      displayName: this.user.displayName,
      email: this.user.email
    }, {merge: true});
    
  }
  getmineMov(){
    return this.movies;
  }
  getmineWish(){
    return this.wish;
  }
  getUser(){
    
    if (this.user==null && this.userSignedIn()){
      
      this.user=JSON.parse(localStorage.getItem("user"));
    }
   
    return this.user;
    
  }

  userSignedIn(): boolean{     
    return JSON.parse(localStorage.getItem('user') || '{}') != null;
    //return JSON.parse(localStorage.getItem("user")) !=null;
  }

  logOut(){

    this.afAuth.signOut();
    localStorage.removeItem("user");
    this.user=null;
    this.router.navigate(["signin"]);
  }

  getMovies(): Observable<any> {
    return this.realtimedb.list<Movie>('movies-list').valueChanges(); 
  }

  addMovie(movie:Movie){
    this.firestore.collection("users").doc(this.user.uid).collection("wishlist").add(movie);
    //movie.inWishlist=true;

  }

  getWishlist(): Observable<any>{
    return this.firestore.collection("users").doc(this.user.uid).collection("wishlist").valueChanges();
  }

  removeMovie(id:string){
    this.firestore.collection("users").doc(this.user.uid).collection("wishlist").doc(id).delete();
    
  }

  
  getWishId(){
    let wishListId:number[]=[];
    //correct line
    //this.getWishlist().pipe(map(movie=>movie.map(elt=>wishListId.push(elt.id)))).subscribe();
    this.firestore.collection("users").doc(this.user.uid).collection<Movie>("wishlist").valueChanges().subscribe(elt => elt.map(x=>wishListId.push(x.id)));
    return wishListId;
    //this.getWishlist().pipe(map(movien => movien.map(element => wishListId.push(element.id)))).subscribe();
    //this.firestore.collection("users").doc(this.user.uid).collection("wishlist").valueChanges().pipe(map(movie=>movie.map(elt=>wishListId.push(elt.id))));


   // return wishListId;
    //return this.firestore.collection("users").doc(this.user.uid).collection("wishlist").valueChanges().pipe(map(document => document.values));
      //return wishListId;
  }
  getWishIdTest(){
    let wishl:number[];
   // this.firestore.collection("users").doc(this.user.uid).collection("wishlist").valueChanges().pipe(map(elt=>wishl=elt.g)).subscribe();
  }
  method1(){
    //let wishListId:number[]=[];
    return this.getWishlist().pipe(map(movien => movien.map(element => this.wish.push(element.id))));
  }
  method2(){

    //let userMovie:Movie[]=[];
    //this.getMovies().subscribe(movies =>{userMovie=movies.filter(movie=> ! this.getWishId().includes(movie.id));});
    //console.log(this.userMovies);
    //return userMovie; 
    return this.getMovies().pipe(map(movien => movien.map(elt => this.movies.push(elt))));
  }
  getMovi(){
    const movies:Movie[]=[];
    this.realtimedb.list<Movie>('movies-list').valueChanges().pipe(map(amovies=> amovies.filter(elt => { [0,1].includes(elt.id)}).map(movie => movies.push(movie)))).subscribe();
    return movies;
  }
  getAllMovies(){
    const allmovies: Movie[]=[];
    return this.realtimedb.list<Movie>('movies-list').valueChanges().pipe(map(movies =>movies.map(elt=>allmovies.push(elt))));//.subscribe
    //return allmovies;
    //.filter(movie => wishmovies.includes(movie.id));
    //return allmovies;
    //allmovies=movies.filter(elt => wishmovies.includes(elt.id)(map(movie => wishmovies.includes(movie.id)))
    //return await this.realtimedb.list<Movie>('movies-list').valueChanges();
  }
  //async getWishId(){
    //let id=[];
    //await this.firestore.collection("users").doc(this.user.uid).collection("wishlist").snapshotChanges().pipe(doc => doc.docs.map(movie =>{return movie.id})).subscribe(id => id.push(id));
    //getDocuments().forEach(value => value.map)
   //let querySnap= await this.firestore.collection("users").doc(this.user.uid).collection("wishlist")
    //.get(); //.toPromise().then(snapshot => {
      //if (snapshot.empty){
        //return [];
      //}
      //return this.getInfoId(snapshot.docs);
    //});
  //}
  /*getInfoId(data){
    return data.map(doc => {
      let info=doc.data();
      return info.id;
    })
  }*/
  //querySnap.forEach(doc => {console.log(doc.id)});
//}

/*getInfo(querySnapDocs) {
    let arrayPhoneNumbers = querySnapDocs.map(docSnap => {
        let info = doc.data();
        let thePhoneNum = info.phoneNumber
        console.log(`thePhoneNum is: ${thePhoneNum}`);
        return thePhoneNum;
      });

    return arrayPhoneNumbers;
  });*/
    

  hideMovie(movies:Movie[],wishlist){
    
  }

}
