import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../movies.service';
import { User } from '../user.model';
import { Movie } from '../movie.model';

import '../app.module.ts';
import { map } from 'rxjs';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  user: User;
  loader=true;
  movie:Movie;
  movies:Movie[]=[];
  wishListId:number[]=[];
  userMovies: Movie[]=[];
  movien:Movie[]=[];
  
  

  constructor(public moviesService:MoviesService) {this.user=this.moviesService.getUser();  //this.movies=this.moviesService.getmineMov();this.wishListId=this.moviesService.getmineWish();
    this.wishListId=this.moviesService.getWishId(); //this.movies=this.moviesService.getAllMovies();
    //this.moviesService.getMovies().subscribe(movies => {this.movies=movies.filter(movie => !this.moviesService.getWishId().includes(movie.id));this.loader=false});
  }

  ngOnInit(): void {











    //this.moviesService.method1().subscribe(()=>this.moviesService.method2());
    //this.moviesService.getWishId().subscribe(movies => {this.moviesService.getMovies().subscribe(elt => this.movies=elt.filter(movie => movies!=movie.id));this.loader=false});
    this.moviesService.getMovies().subscribe(movies=>{this.movies=movies.filter(elt=>!this.wishListId.includes(elt.id));this.loader=false});
    //this.movies=this.moviesService.mineMov.filter(elt => this.moviesService.mineWish.includes(elt.id));
    //his.movies=this.moviesService.getmineMov();
    //this.moviesService.getWishId().subscribe(elt=> this.moviesService.getMovies().pipe(map(movien => movien.filter(elt1 => elt1.id!=elt.id).map(element => this.movies.push(element.id)))));

    //this.moviesService.method1().subscribe((movie)=>this.movies=movie.this.moviesService.getMovies().subscribe(elt => {elt.id!=movie.id;this.loader=false}));
    //this.moviesService.getMovies().subscribe(movies => this.movies=movies);
    //this.movies.filter(movie => !this.wishListId.includes(movie.id)).map(movie => this.userMovies.push(movie));
    //this.userMovies.push(this.movies.filter(movie => {! this.wishListId.includes(movie.id)}));
    //this.moviesService.getMovies().pipe(map(movie => movie.map(element => element.filter(!this.wishListId.includes(element.id)))));
    //this.movies=this.moviesService.getAllMovies();
    //this.movies=this.movies.filter(movie=>movie.id!=2);
    //let wishmovies:number[]=this.wishListId;

    //this.movies=this.moviesService.getMovi(wishmovies);//.filter(m => this.wishListId.includes(m.id));
    //this.moviesService.getMovies().subscribe(movie =>this.movies=movie);
    //this.movies=this.movies.filter(movie=> wishmovies.includes(movie.id));
    //this.loader=false;
    //this.userMovies=this.moviesService.getAllMovies();
    //this.userMovies=this.userMovies.filter(movie=>wishmovies.includes(movie.id));
    console.log(this.movies);
    //console.log(wishmovies);
    
    console.log(this.wishListId);
    //console.log(this.userMovies);
   // this.movies.map(movie => this.userMovies.push(movie));
    //const movie1:Movie={genre: 'Biography', id: 1, title: '127 Hours', year: 2};
    this.movien=[{genre: 'Biography', id: 1, title: '127 Hours', year: 2},{genre: 'Biography', id: 3, title: '127 Hours', year: 2}];
    this.movien=this.movien.filter(movie => this.wishListId.includes(movie.id));
   console.log(this.movien);
    //this.moviesService.getMovies().subscribe(movies => {this.movies=movies.filter(movie => !this.wishListId.includes(movie.id));this.loader=false});
    //this.moviesService.getMovies().subscribe(movies => {this.movies=movies.filter(movie => !this.moviesService.getWishId().includes(movie.id));});
   // this.moviesService.getAllMovies().then(movie => map(movie=>{this.movies=movie.filter(movie => !this.moviesService.getWishId().includes(movie.id));})
    //this.loader=false;
    
  }
 

  addMovieToWishlist(movie){
    this.moviesService.addMovie(movie);
    this.movies=this.movies.filter(omovie => omovie!=movie);
  }
}
